#include <iostream>
#include <fstream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
class histo{
	public:
		int r;
		int c;
		int mi;
		int ma;
		int* histogram;
	histo(int row, int col, int min, int max){
		r=row;
		c=col;
		mi=min;
		ma=max;
		histogram = new int[max];
		for(int i=0; i<max; i++){
			histogram[i]=0;
		}
	}
	void computeHistogram(int index){
		histogram[index]++;	
	}
	void print(ofstream& outfile, int max){
		for(int i=0; i<= max;i++){
			if(histogram[i]>=80){
				outfile<<"("<<i<<"):"<<"80 +'s";
				outfile<<endl;
			}
			else{
				outfile<<"("<<i<<"):"<<histogram[i];
			//	outfile<<endl;
				for(int j=0;j<histogram[i];j++){
					outfile<<"+";
				}
				outfile<<endl;
			}
		}
	}
	
};
int main(int argc, char** argv) {
	//cout<<"hello "<<endl;
	 if ( argc < 2 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {
	    //something...
	    int string;
	    int count=0;
	    int row;
	    int col;
	    int min;
	    int max;
	    int** inputArray;
	    
	    ofstream outfile1;
	    outfile1.open(argv[2]);
	    	while(the_file>>string){
	    		count++;
	    		if(count==1){
	    			row=string;
	    			cout<<row<<endl;
				}
				else if(count==2){
					col=string;
					cout<<col<<endl;
				}
				else if(count == 3){
					min=string;
					cout<<min<<endl;
				}
				else if(count ==4){
					max=string;
					cout<<max<<endl;
				}
				else{
					break;
				}
			}
			histo test(row,col,min,max);
			inputArray= new int*[row];
			for(int i =0; i <row;++i){
				inputArray[i]= new int[col];
			}
			for(int r = 0; r<row;r++){
				for(int c= 0; c<col; c++){
				inputArray[r][c]=0;	
				}
			 }
			 for(int r= 0; r<row;r++){
			 	for(int c= 0; c<col;c++){
			 		while(the_file>>string){
			 			inputArray[r][c]=string;
			 			test.computeHistogram(inputArray[r][c]);
					 }
			 		
				 }
			 }
			 test.print(outfile1,max);
			 the_file.close();
			 outfile1.close();
			 
			 
		}//else
	}
	return 0;
}
