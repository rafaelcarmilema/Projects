#include <iostream>
#include <fstream>
using namespace std;
class graphNode{
	private:
		int nodeID;
		graphNode* next;
		graphNode* isEmpty;
	public:
		graphNode(int id){
			nodeID=id;
			next=NULL;
			
		}
		graphNode(int id, graphNode* n){
			nodeID=id;
			next=n;
			
		}
		~graphNode(){
			delete(next);
		}
		friend class PrimMST;
};

class edgeNode{
	private:
	int Ni;
	int Nj;
	int edgeCost;
	edgeNode* next;
	public:
	edgeNode(int ni, int nj, int cost ){
		Ni=ni;
		Nj=nj;
		edgeCost=cost;
		next=NULL;
	}
	edgeNode(int ni, int nj, int cost, edgeNode* n ){
		Ni=ni;
		Nj=nj;
		edgeCost=cost;
		next=n;
	}
	~edgeNode(){
		delete (next);
	}
	friend class PrimMST;
};

class PrimMST{
	private:
		int N;
		int totalCost=0;
		int* graphNodeIDarray;
		edgeNode* edgeList;
		edgeNode* MSTofG;
		graphNode* setA;
		graphNode* setB;
	public:
		PrimMST(int nodes){
			N=nodes;
			edgeList = new edgeNode(-9999,-9999,-9999);
			setA= new graphNode(-9999);
			setB= new graphNode(-9999);
			MSTofG= new edgeNode(-9999,-9999,-9999);
			graphNodeIDarray= new int[N+1];
			for(int i=0;i<=N;i++){
				graphNodeIDarray[i]=0;
			}
		}
		
		void PrimAlgorithm(ifstream& infile, ofstream& out1, ofstream& out2){
		  int r, ni, nj, cost;
		  int r2;
		  int r3;
			 while (infile>>r>>r2>>r3){
	      		ni=r;
	      		nj=r2;
	      		cost=r3;
	      		//cout<<ni<< " "<<nj<<" "<<cost<<endl;
	      		insertEdges(ni,nj,cost);
	      		graphNodeIDarray[ni]++;
	      		graphNodeIDarray[nj]++;
		  }
		printArray(out2);
		printEdges(out2); 
		int k=findFirstNonZero();
		insertSetA(k);
		findNextNonZero(k); // insertion for set B happends inside this method
		out2<<"Sets at the beggining:"<<endl;
		printSetA(out2);
		printSetB(out2);
		// Step 7

			while(setB->next!=NULL){
				edgeNode* curr =findMinEdge(); // minedge
				//cout<<curr->Ni<<" "<<curr->Nj<<"testing mindedge "<<curr->edgeCost<<endl;
				totalCost+=curr->edgeCost;
				insertMSTofG(curr);
		
				
				if(searchB(curr->Ni)){
					insertSetA(curr->Ni);
					removeB(curr->Ni);
				}
				else {
					insertSetA(curr->Nj);
					removeB(curr->Nj);
				}
				printSetA(out2);
				printSetB(out2);
				printMSTofG(out2);
		
				//cout<<curr->Ni<<" "<<curr->Nj<<" "<<curr->edgeCost<<endl;
			}
			out2<<"Sets at the End:"<<endl;
			printSetA(out2);
			printSetB(out2);
			out1<<"Final MST"<<endl;
			printMSTofG(out1);
			out1<<"TOTAL COST: "<< totalCost<<endl;
		}
		void removeTestB(){
			graphNode* curr=setB;
			while(setB->next!=NULL){
				
				
			}
			
		
		}
		void insertMSTofG(edgeNode* minEdge){ 
			edgeNode* curr=MSTofG;
				while(curr->next!=NULL){
					curr=curr->next;
				}
				curr->next=minEdge;
		}
		void printMSTofG(ofstream& out2){
			out2<<"*********MST*********"<<endl;
			edgeNode* curr=MSTofG;
			while(curr!=NULL){
				out2<<curr->Ni<<" "<<curr->Nj<<" "<<curr->edgeCost<<endl;
				curr=curr->next;
			}
			out2<<endl;
		}
		edgeNode* findMinEdge(){
			edgeNode* curr= edgeList->next;
			edgeNode* previous=edgeList->next;
			while(curr!=NULL){
				if((searchA(curr->Ni))&&(searchA(curr->Nj))){ // both are in set a
					previous=curr;
					curr=curr->next;
				}
				else if((searchB(curr->Ni))&&(searchB(curr->Nj))){// both are in set b
					previous=curr;
					curr=curr->next;
				}
				else{
					edgeNode* temp=removeEdge(curr);
					return temp;
				}
				
			}
	
			
		}
		edgeNode* removeEdge(edgeNode* minEdge){
				edgeNode* edge;
	
				edgeNode* previous = edgeList;
				edgeNode* current = edgeList->next;
				while (current!=NULL ){
					if((minEdge->Ni==current->Ni)&&(minEdge->Nj==current->Nj)&&(minEdge->edgeCost==current->edgeCost)){
						 edge=current;
						 previous->next=current->next;
						 edge->next=NULL;
						
						 //case 2 & 3
						return edge;
						//free(current);
					} else {
						previous = current;
						current = current->next;
					}
				} // while
				//return false;
	
			return NULL;
			
		}
		void removeB(int x){
			if (x==setB->nodeID){
				setB = setB->next; // case 1: delete the head

			} else {
				graphNode* previous = setB;
				graphNode* current = setB->next;
				while (current!=NULL){
					if(x == current->nodeID){
						previous->next=current->next; //case 2 & 3
						free (current);
						break;
					} else {
						previous = current;
						current = current->next;
					}
				} // while
			
			}
			
		}
		bool searchB(int idnode){
			graphNode* curr=setB->next;
			while(curr!=NULL){
				if(curr->nodeID==idnode){
					return true;
				}
				else{
				curr=curr->next;
				}
			}
			
		}
		bool searchA(int idnode){
			graphNode* curr=setA->next;
			while(curr!=NULL){
				if(curr->nodeID==idnode){
					return true;
				}
				else{
				curr=curr->next;
				}
			}
			
		}
		void insertEdges(int ni,int nj,int cost){
			if(edgeList->edgeCost>cost){//insert at the head
					edgeList=new edgeNode(ni,nj,cost,edgeList);
				}
				else{
					edgeNode* current = edgeList;
					edgeNode* previous = edgeList;
						while (current != NULL){
							if(current->edgeCost<cost){
								previous = current;
								current = current->next;
							}else { 
								previous->next=new edgeNode(ni,nj,cost,current);
								break; // case 2: insert into middle
							
							} // if/else
						} // while
				if (current == NULL){
					previous->next=new edgeNode(ni,nj,cost);
					//previous.setNext(new Node(x)); // case 3: insert at end
					}
						
				}					
		}
		
		void insertSetA(int id){
			graphNode* curr=setA;
				while(curr->next!=NULL){
					curr=curr->next;
				}
				curr->next=new graphNode(id);
			
		}
		void insertSetB(int id){
			graphNode* curr=setB;
				while(curr->next!=NULL){
					curr=curr->next;
				}
				curr->next=new graphNode(id);
		}
		void printEdges(ofstream& out2){			
			edgeNode* curr= edgeList;
			int count=0;
			out2<<"*********First 10 Edges*********"<<endl;
			while(curr!=NULL){
				if(count<=10){
				out2<<curr->Ni<<" "<<curr->Nj<<" "<<curr->edgeCost<<endl;
				curr=curr->next;
				count++;
				}
				else 
				break;
			}
			out2<<endl;
		}
		void printArray(ofstream& out2){
		out2<<"*********GraphNodeIDArray*********"<<endl;
		for(int i=0;i<=N;i++){
			out2<<"["<<i<<"] "<<graphNodeIDarray[i]<<endl;
		}
		out2<<endl;
	}
		void printSetA(ofstream& out2){
			out2<<"*********Set A********* "<<endl;
			graphNode* curr=setA;
			while(curr!=NULL){
				out2<<curr->nodeID<<endl;
				curr=curr->next;
			}
			out2<<endl;
		}
		void printSetB(ofstream& out2){
			out2<<"*********Set B*********"<<endl;
			graphNode* curr=setB;
			while(curr!=NULL){
				out2<<curr->nodeID<<endl;
				curr=curr->next;
			}
			out2<<endl;
		}
	void findNextNonZero(int k){
		int k1;
		for(int i=0;i<=N;i++){
			if((graphNodeIDarray[i]!=0)&&(i!=k)){
			k1=i;
			insertSetB(k1);
			}
		}	
	}
	int findFirstNonZero(){
		int k;
		for(int i=0;i<=N;i++){
			if(graphNodeIDarray[i]!=0){
			k=i;
			break;
			}
		}
	return k;
	}
	
	
};

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	 if ( argc < 3 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {
		  int r;
	      int nodes;
	      int count =0;
	      ofstream outfile1;
	      ofstream outfile2;
		  outfile1.open(argv[2]);
		  outfile2.open(argv[3]);
	      while ( the_file>>r){	 
		  			count++;     	
	    	     	if(count==1){
	    	     		nodes=r;
	    	     		//cout<<nodes<<endl;
	    	     		break;
					 }	  
	     	      }	 
		PrimMST test(nodes);  
 		test.PrimAlgorithm(the_file,outfile1, outfile2);
	    the_file.close();
		outfile1.close();			
    	outfile2.close();	
		}
	}
	return 0;
}
