#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream> 
#include <math.h> 
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
class Euclean{
	private:
		int row;
		int col;
		int min;
		int max;
		int newmin;
		int newmax;	
		double** zeroFramedAry;
		double neighborAry[5];	
		public:
			Euclean(int r, int c, int mi, int ma){
				row=r;
				col=c;
				min=mi;
				max=ma;
				
				zeroFramedAry = new double*[r+2];
				for(int i=0; i <r+2;i++){
					zeroFramedAry[i]= new double [c+2];
				}
				//initialize the 2d threshold array 
				for(int i=0;i<r+2;i++){
					for(int j=0; j<c+2;j++ ){
						zeroFramedAry[i][j]=0;
					}
				}
			}
		void loadImage(int value, int r, int c){
		zeroFramedAry[r+1][c+1]=value;
		
		}
		void loadNeighborsPass1(int a, int b){
				//uppper left
			neighborAry[0]=zeroFramedAry[a-1][b-1];
			//upper middle
			neighborAry[1]=zeroFramedAry[a-1][b];
			//upper right
			neighborAry[2]=zeroFramedAry[a-1][b+1];
			//left next to p(i,j)
			neighborAry[3]=zeroFramedAry[a][b-1];
			
			
		}
		double findMin(){
			int minimumd;
			double euclean= sqrt(2);
			neighborAry[0]=neighborAry[0]+euclean;
			//cout<<neighborAry[0]<<endl;			//upper middle
			neighborAry[1]=neighborAry[1]+1;
			//upper right
			neighborAry[2]=neighborAry[2]+euclean;
			//left next to p(i,j)
			neighborAry[3]=neighborAry[3]+1;
			minimumd=neighborAry[0];
		for(int i=0;i<4;i++){
			if(minimumd>neighborAry[i]){
				minimumd=neighborAry[i];
			}
			//return minimumd;
		}
		return minimumd;	
			
			
		}
		void FirstPassEucleanDistance(){
			newmin=0;
			newmax=0;
			for(int i=1; i<=row;i++){
				for(int j=1; j<=col;j++){
					if(zeroFramedAry[i][j]>0){
						loadNeighborsPass1(i,j);
						zeroFramedAry[i][j]=findMin();
						if(newmin>zeroFramedAry[i][j]){
							newmin=zeroFramedAry[i][j];
						}
						if(newmax<zeroFramedAry[i][j]){
							newmax=zeroFramedAry[i][j];
						}
						
					}
				}
			}// outer most for loop
		}
			void loadNeighborsPass2(int a, int b){
			//right of p(i,j)
			neighborAry[0]=zeroFramedAry[a][b+1];
			//lower left
			neighborAry[1]=zeroFramedAry[a+1][b-1];
			//lower middle
			neighborAry[2]=zeroFramedAry[a+1][b];
			//lower right
			neighborAry[3]=zeroFramedAry[a+1][b+1];
			//itself
			neighborAry[4]=zeroFramedAry[a][b];
			
		}	
		double findMinPass2(){
			int minimumd;
			double euclean= sqrt(2);
				//right next to p(ij)
			neighborAry[0]=neighborAry[0]+1;
			//lower left
			neighborAry[1]=neighborAry[1]+euclean;
			//lower middle
			neighborAry[2]=neighborAry[2]+1;
			//lower right
			neighborAry[3]=neighborAry[3]+euclean;
			minimumd=neighborAry[0];
			for(int i=0;i<4;i++){
				if(minimumd>neighborAry[i]){
					minimumd=neighborAry[i];
				}
			}
			//check with p(i,j)
			if(minimumd>neighborAry[4]){
				minimumd=neighborAry[4];
			}
			return minimumd;
			
			
		}
		void SecondPassEucleanDistance(){
			newmin=0;
			newmax=0;
			for(int i = row ; i >= 1 ; i--){
      			for(int j = col; j >= 1; j--){
      				if(zeroFramedAry[i][j] > 0){
      					loadNeighborsPass2(i,j);
      					zeroFramedAry[i][j]=findMinPass2();
      						if(newmin>zeroFramedAry[i][j]){
							newmin=zeroFramedAry[i][j];
						}
						if(newmax<zeroFramedAry[i][j]){
							newmax=zeroFramedAry[i][j];
						}
      				}
      			}
      		}//outer for loop			
      				
		}
		
		
		
		void PrintZeroFramed(){
			cout<<row<<" "<<col<<" "<<newmin<<" "<<newmax<<endl;
			for(int i=1;i<=row;i++){
				for(int j=1;j<=col;j++){
					cout<<zeroFramedAry[i][j];
					
				}
				cout<<endl;
			}
			
		}
		void PrettyPrint(ofstream& outfile2){
			outfile2<<row<<" "<<col<<" "<<newmin<<" "<<newmax<<endl;
				for(int i=1;i<=row;i++){
				for(int j=1;j<=col;j++){
					if(zeroFramedAry[i][j]==0){
						outfile2<<" ";
					}
					else{
						outfile2<<(int) (zeroFramedAry[i][j]+.5);
					}
				}
				outfile2<<endl;
			}	
}
};
int main(int argc, char** argv) {
		if ( argc <3 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {
		    int row;
		    int col;
		    int min;
		    int max;
		    int string;
		    int data;
		    int** inputArray;		    
	    	ofstream outfile1;
	    	ofstream outfile2;
	    	outfile2.open(argv[3]);
	    	outfile1.open(argv[2]);
	    	//Get the header values
	    	the_file>>data;
	    	row=data;
	    	
	    	the_file>>data;
	    	col=data;
	    	
	    	the_file>>data;
	    	min=data;
	    	
	    	the_file>>data;
	    	max=data;	
			cout<<row<<" "<<col<<" "<<min<<" "<<max<<endl;
			Euclean test(row,col,min,max);
			inputArray= new int*[row];
			for(int i =0; i <row;++i){
				inputArray[i]= new int[col];
			}
			for(int r = 0; r<row;r++){
				for(int c= 0; c<col; c++){
				inputArray[r][c]=0;	
				}
			 }
			for(int r= 0; r<row;r++){
			 	for(int c= 0; c<col;c++){
			 		while(the_file>>string){
			 			inputArray[r][c]=string;
			 			test.loadImage(string,r ,c);
			 			//cout<<r<<" "<< c<<" "<<string<<endl;
			 			break;
					 }
			 		
				 }
			//	 cout<<endl;
			 }
			 
			 test.PrintZeroFramed();
			 test.FirstPassEucleanDistance();
			 cout<<endl;
			 cout<<"PASS 1"<<endl;
			 test.PrintZeroFramed();
			 outfile2<<"PASS 1"<<endl;
			 test.PrettyPrint(outfile2);
			 test.SecondPassEucleanDistance();
			 cout<<"PASS 2"<<endl;
			 test.PrintZeroFramed();
			 outfile1<<"PASS 2"<<endl;
			 test.PrettyPrint(outfile1);
			 outfile2<<"PASS 2"<<endl;
			 test.PrettyPrint(outfile2);
			 	the_file.close();
			outfile1.close();
			outfile2.close();
		}//else
	
	}	
	return 0;
}
