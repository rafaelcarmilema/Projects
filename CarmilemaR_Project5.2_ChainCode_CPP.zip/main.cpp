#include <iostream>
#include <fstream>
#include <string>
#include <sstream> 
#include <limits>
using namespace std;

class Image{
	int numRows;
    int numCols;
	int minVal;
    int maxVal;
    int** zeroFramedAry;
    
    public:
    	Image(ifstream& the_file){
    		int data;
    		//get the header values
    		the_file>>data;
	    	numRows=data;
	    	
	    	the_file>>data;
	    	numCols=data;
	    	
	    	the_file>>data;
	    	minVal=data;
	    	
	    	the_file>>data;
	    	maxVal=data;
    
		    // allocate zeroframed 2d array
			zeroFramedAry= new int*[numRows+2];
			for(int i=0; i<numRows+2;i++){
				zeroFramedAry[i]= new int [numCols+2];
			}
			
			//ini
			for(int i=0; i<numRows+2; i++){
				for(int j=0;j <numCols+2;j++){
					zeroFramedAry[i][j]=0;
				}
			}
		    for(int r= 0; r<numRows;r++){
			 	for(int c= 0; c<numCols;c++){
			 		while(the_file>>data){
			 			loadImage(data,r ,c);
			 			//cout<<r<<" "<< c<<" "<<string<<endl;
			 			break;
					 }
			 		
				 }
			//	 cout<<endl;
			 }
    		
		}
	void loadImage(int value, int r, int c){
		zeroFramedAry[r+1][c+1]=value;
		
		}
	void prettyPrint(ofstream& out1){
		out1<<"Pretty Print"<<endl;
		out1<<numRows<<" "<<numCols<<" "<<minVal<<" "<<maxVal<<endl;
			for(int i=1; i<=numRows;i++){
				for(int j=1; j<=numCols;j++){
					if(zeroFramedAry[i][j]>0){
						out1<<zeroFramedAry[i][j];
					}
					else{
						out1<<" ";
					}
					//outfile1<<zeroFramedAry[i][j]<<" ";					
			}
		out1<<endl;
		//cout<<endl;
		}
	}
	friend class chainCode;
};

class CCproperty{
		struct property{
			int label;
			int numPixels;
			int minRow;
			int minCol;
			int maxRow;
			int maxCol;
		
	};	
	int maxCC;
	property* table;
	public:
	
	 CCproperty(ifstream& the_PP){
	 		int mCC;
	 		// thiw will go back to the beggining of the file rather than open and close it 
	 		while(the_PP>>mCC){
	 			the_PP.ignore(numeric_limits<streamsize>::max(),'\n');
			 }
			 the_PP.clear();
			 the_PP.seekg(0,the_PP.beg);
			 
			maxCC=mCC;
			table = new property[maxCC+1];
			for(int i=1; i<maxCC+1;i++){
				the_PP>>table[i].label;
				the_PP>>table[i].minRow;
				the_PP>>table[i].minCol;
				the_PP>>table[i].maxRow;;
				the_PP>>table[i].maxCol;
				the_PP>>table[i].numPixels;
				
			}
	
	
		
	}
	
	friend class chainCode;
};

class chainCode{
	public:
		struct point{
			int row;
			int col;
		};
		//public:
		int currentCC;
		int minRowOffset;
		int maxRowOffset;
		int minColOffset;
		int maxColOffset;
		CCproperty* t;
		Image* imag;
		point neighborCoord[8];
		int nextDirTable[8]={6,0,0,2,2,4,4,6};
		point currentP, nextP,startP;
		int nextQ, Pchain, lastQ;
	
		public:	
		chainCode(ifstream& the_file,ifstream& the_PP){
			 t=new CCproperty(the_PP);
			 imag=new Image(the_file);
			 
			currentCC=0;
			
		}
		void calculateChain(ofstream& out1,ofstream& out2){
			while(currentCC<t->maxCC){

				currentCC++;
				cout<<currentCC<<endl;
				minRowOffset=t->table[currentCC].minRow;
				maxRowOffset=t->table[currentCC].maxRow;
				minColOffset=t->table[currentCC].minCol;
				maxColOffset=t->table[currentCC].maxCol;
				for(int i= minRowOffset+1; i< maxRowOffset+1;i++){
					for(int j=minColOffset+1; j<maxColOffset+1;j++){
						if(imag->zeroFramedAry[i][j]==currentCC){
							out1<<i<<" "<<j<<" "<<currentCC<<endl;
							startP.row=i;
							startP.col=j;
							
							currentP.row=i;
							currentP.col=j;
							goto finish;
							//break;
							}	
						
					}
				}
				finish:
			out2<<currentP.row<<" out  "<<currentP.col<<endl;
							out1<<"PChain:"<<endl;
							lastQ=4;
							nextQ=(lastQ)%8;
								Pchain=findNextP(currentP,nextQ,currentCC);
								out1<<Pchain<<" ";
								
								lastQ=nextDirTable[Pchain];
								currentP.row=nextP.row;
								currentP.col=nextP.col;
								
							while(currentP.row!=startP.row||currentP.col!=startP.col){
								nextQ=(lastQ)%8;
								Pchain=findNextP(currentP,nextQ,currentCC);
								out1<<Pchain<<" ";
								lastQ=nextDirTable[Pchain];
								currentP.row=nextP.row;
								currentP.col=nextP.col;
							}//end of while
							out1<<endl;
							out1<<endl;
				out2<<minRowOffset<<" "<<maxRowOffset<<" "<<minColOffset<<" "<<maxColOffset<<endl;
				
			}
			
		}
		void loadNeighborsCoord(point currP){
			int i=currP.row;
			int j=currP.col;
			//upper left
			neighborCoord[3].row=i-1;
			neighborCoord[3].col=j-1;
			//upper middle
			neighborCoord[2].row=i-1;
			neighborCoord[2].col=j;
			//upper right
			neighborCoord[1].row=i-1;
			neighborCoord[1].col=j+1;
			//middle left
			neighborCoord[4].row=i;
			neighborCoord[4].col=j-1;
			//middle right
			neighborCoord[0].row=i;
			neighborCoord[0].col=j+1;
			//bottom left
			neighborCoord[5].row=i+1;
			neighborCoord[5].col=j-1;
			//bottom middle
			neighborCoord[6].row=i+1;
			neighborCoord[6].col=j;
			//bottom right
			neighborCoord[7].row=i+1;
			neighborCoord[7].col=j+1;
			
			
		}
		int findNextP(point currP, int nQ, int currCC){
			loadNeighborsCoord(currP);
			int chainDir;
			for(int i=nQ; i<nQ+8;i++){
				if(imag->zeroFramedAry[neighborCoord[i%8].row][neighborCoord[i%8].col]==currCC){
					//out2<<neighborCoord[i%8].row<<" nextp "<<neighborCoord[i%8].col<<endl;
					chainDir=i%8;
					break;
				}//end of if
			}//end of for
			
			nextP.row=neighborCoord[chainDir].row;
			nextP.col=neighborCoord[chainDir].col;
			return chainDir;
		}
		void prettyPrint(ofstream& out1){
			imag->prettyPrint(out1);
		}
};
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	 if ( argc <4 ) // argc should be 4 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    ifstream the_PP(argv[2]);
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {  
	    	ofstream outfile1;
	    	ofstream outfile2;
	    	outfile1.open(argv[3]);
	    	outfile2.open(argv[4]);
	    	
	    	
			chainCode testing(the_file,the_PP);
			testing.calculateChain(outfile1,outfile2);
			testing.prettyPrint(outfile1);
			
			the_file.close();
			the_PP.close();
			outfile1.close();
			outfile2.close();	
  		}//else
	}
			
			
		
			
	
	return 0;
}
