import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if ( args.length < 4 ){ // the number of arguments should be 4
			System.err.println("Invalid number of arguments.");
			System.exit(1);
			}
		    else {
	        File file = new File(args[0]);
	        File file2 = new File(args[1]);
	       
	     
	        int count=0;
	        int nodes=0;

	       
	        try {
	        	PrintWriter outfile1 = new PrintWriter(args[2]);
	        	PrintWriter outfile2 = new PrintWriter(args[3]);
	            Scanner infile = new Scanner(file);
	            while (infile.hasNext()) {
	            	count++;
	            	if(count==1){
	            		nodes=infile.nextInt();
	            		System.out.println(nodes);
	            		break;
	            	}
	                 // got nodes    
	            }
	            
	            Scanner infile2 = new Scanner(file2);
	            int sourceNode=0;
	            while(infile2.hasNext()){
	            	sourceNode=infile2.nextInt();
	            }
	            System.out.println("source "+sourceNode);          
	            DijktraSSS test= new DijktraSSS(nodes,sourceNode);
	            test.Dijkstras(infile,outfile1, outfile2);
	            infile.close();
	            infile2.close();
	            outfile1.close();
	            outfile2.close();
	        } 
	        catch (FileNotFoundException e){
	            System.out.println("File not found.");
	        }
		}
  }
}
