import java.io.PrintWriter;
import java.util.Scanner;

public class DijktraSSS {
	int N;
	int sourceNode;
	int minNode;
	int currentNode;
	int newCost;
	int costMatrix[][];
	int fatherArray[];
	int markedArray[];
	int bestCostArray[];
	boolean flag=true;
	public DijktraSSS(int n,int source){
		N=n;
		sourceNode=source;
		fatherArray=new int[N+1];
		for(int i=1;i<=N;i++){
			fatherArray[i]=i;
		}
		markedArray = new int[N+1];
		for(int i=1;i<=N;i++){
			markedArray[i]=0;
		}
		bestCostArray = new int[N+1];
		for(int i=1;i<=N;i++){
			bestCostArray[i]=9999;
		}
		costMatrix = new int[N+1][N+1];
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				costMatrix[i][j]=9999;
				costMatrix[i][i]=0;
			}
		}
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				System.out.print(costMatrix[i][j]+" ");
			}
			System.out.println();
		}
		
	}
	public int computeCost(int min, int current){
	 int cost=0;
	 cost=bestCostArray[min]+costMatrix[min][current];
	return cost;
		
	}
	public void updateMarkedArray(){
		
	}
	public void debugPrint(){
		
	}
	public void printCostMatrix(PrintWriter out2){
		out2.println("COST MATRIX: ");
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				out2.print(costMatrix[i][j]+" ");
			}
			out2.println();
		}
	}
	public void Dijkstras(Scanner infile,PrintWriter out1, PrintWriter out2){
		//Step 0
		bestCostArray[sourceNode]=0;
		int x=0;
       
        int ni=0;
        int nj=0;
        int cost=0;
       
	 //step 1 & 2
		int counter=0;
		
        while (infile.hasNext()) {
        	counter++;
        	if(counter==1){
        		x=infile.nextInt();
        		ni=x;
        	}
        	else if(counter==2){
        		x=infile.nextInt();
        		nj=x;
        	}
        	else if(counter==3){
        		x=infile.nextInt();
        		cost=x;
        		System.out.println(ni+" "+nj+" "+cost);
        		costMatrix[ni][nj]=cost;
        		counter=0;
        	}	                     
        }
        out2.println("Source Node: "+sourceNode);
        out2.println();
        //printCostMatrix(out2);
        out2.println("****************************************");
        out2.println("INITIAL ARRAYS");
        out2.println();
        printFather(out2);
        out2.println();
        printBestCost(out2);
        out2.println();
        printCostMatrix(out2);
        out2.println();
        printMarked(out2);
        out2.println();
        out2.println("****************************************");
        while(flag){
        //Step4 
        checkFlag();	// check if there are unmarked nodes
        minNode=unmarkedMin();
        //minNode=findUnmarked();
        out2.println("********** MinNode *********");
        out2.println(" MinNode ="+minNode);
        markedArray[minNode]=1; // marking node
        printMarked(out2);
        System.out.println("marked "+minNode);
        //step5
        for(int i=1;i<=N;i++){ //doing it for all unmarked step 6
        	if(markedArray[i]==0){
        		currentNode=i;
        	    newCost=computeCost(minNode, currentNode);
        	    if(newCost<bestCostArray[currentNode]){
                	updateFatherArray(currentNode,minNode);
                	updateBestCost(currentNode,newCost);
                	printFather(out2);
                	out2.println();
                	printBestCost(out2);
                }//end of inner if 
        	}// end of outer if
        }// end of for loop
        
        //Step 8-10
        //findNprintShortestPath(fatherArray[1]);
        /*for(int i=1;i<=N;i++){
        	System.out.println(fatherArray[i]);
        	findNprintShortestPath(fatherArray[i]);
        }
        */
      }
        out2.println("*****************************************************");
        out2.println("FINAL ARRAYS:");
        out2.println();
        printFather(out2);
        out2.println();
        printBestCost(out2);
        out2.println();
        printMarked(out2);
        out2.println("*****************************************************");
        //Step 8-10
        out1.println("*********** Shortest Path ***********");
        for(int i=1;i<=N;i++){
        	out1.print(i+"<-");
        	findNprintShortestPath(fatherArray[i],out1);
        	out1.print("="+bestCostArray[i]);
        	out1.println();
        }
       
        
	}
	public void  findNprintShortestPath(int parent,PrintWriter out1){
		if(sourceNode==parent){
			out1.print(parent);
			return;
		}
		else{
			out1.print(parent+"<-");
			findNprintShortestPath(fatherArray[parent],out1);
		}
		
	}
	public void printMarked(PrintWriter out2){
		out2.println("Marked Array:");
		for(int i=1;i<=N;i++){
			out2.print(markedArray[i]+" ");
		}
		out2.println();
	}
	public void printBestCost(PrintWriter out2){
		out2.println("Best Cost Array:");
		for(int i=1;i<=N;i++){
			out2.print(bestCostArray[i]+" ");
		}
		out2.println();
	}
	public void printFather(PrintWriter out2){
		out2.println("Father Array:");
		for(int i=1;i<=N;i++){
			out2.print(fatherArray[i]+" ");
		}
		out2.println();
	}
	public void updateBestCost(int curr, int cost){
		bestCostArray[curr]=cost;
	}
	public void updateFatherArray(int curr,int min){
		fatherArray[curr]=min;
	}
	public int unmarkedMin(){
		int min=999999;
		int minNode=0;
		for(int i=1;i<=N;i++){
			if(min>bestCostArray[i]&&markedArray[i]!=1){
				min=bestCostArray[i];
				minNode=i;
			}
		}
		return minNode;
	}
	public void checkFlag(){
		
		for(int i=1;i<=N;i++){
			if(markedArray[i]==0){
				//markedArray[i]=1;
				flag=true;
				
				break;
			}
			else{
				flag=false;
			}
		}
	}
}
