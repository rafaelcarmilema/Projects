#include <iostream>
#include<fstream>
using namespace std;
class Node{
	private:
	Node* next;	
    string data;  
	public:  
	//constructor
	Node(string d){
		data=d;
		next=NULL;
	}
	Node(string d, Node* n){
		data=d;
		next=n;
	}
	~Node(){
		delete (next);
	}
	friend class LinkedListStack;
};

class LinkedListStack{
	private:
	Node* Top;
	int count=0;
	
	public:
	LinkedListStack(){
		Top =NULL;	
	}	
	void push(string d){	
		Node* newTop;
		if(isEmpty()){
			newTop= new Node(d,NULL);
		//	newTop->data =d;
		//	newTop->next=NULL;
			Top= newTop;
			count++;
		}
		else{
			newTop= new Node(d,Top);
			//newTop->data=d;
			//newTop->next=Top;
			Top= newTop;
			count++;
		}
	}
	string pop(){
		if(isEmpty()){
			cout<<"The Stack is empty"<<endl;
			return 0;
		}
		Node* temp=Top;
		Top=Top->next;
		count--;
		free(temp);
		return temp->data;
		
	}
	bool isEmpty(){
		if(count==0){
		return true;
		}
		return false;
		
	}
	void printStack(){
		cout<<"STACK:"<<endl;
		for(Node* p=Top; p!=NULL;p=p->next)
			cout<<p->data<<endl;
	}
	void printFile(char* argv[]){
	 	ofstream outfile;
	    outfile.open(argv[2]);
		outfile<<"STACK:"<<endl;
		for(Node* p=Top; p!=NULL;p=p->next)
		 outfile<<p->data<<endl;
		 outfile.close();	 
	}
};


int main(int argc, char** argv) {
	LinkedListStack test;
	
	 if ( argc < 2 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {
		  string r="";
	      int x;
	     
	      // the_file.get ( x ) returns false if the end of the file
	      //  is reached or an error occurs
	      while ( the_file>>r){
	    	      //cout<<r<<endl;
	    	      test.push(r);
	    	  	  //cout<<x<<endl;

	     	      }
	           
	      the_file.close();
		 test.printFile(argv); // print in file 
		 test.printStack(); // print 
		
			
    return 0;
	
	
		
		}
	
	}
	

}
