package radixsort;

import java.io.PrintWriter;

public class LinkedListQueue {
	private Node front;
	private	Node rear;
		int count=0;
	LinkedListQueue(){
		front = new Node ("-9999",null);
		rear = front;
		
	}	

	void addTail(String data){
		if(front.getNext()==null){
			front.setNext(new Node(data,null));
			rear= front.getNext();
			
		}
	    rear.setNext(new Node(data,null));
		rear=rear.getNext();
	}
	
	public String deleteHead(){
		Node temp=front.getNext();
		if(isEmpty()){
			System.out.println("The Queue is Empty");
			return null;
		}
	
		else{
			
			front.setNext(front.getNext().getNext());			
			String d=temp.getData();
			return d;
		}
	
	}
	boolean isEmpty(){
		if(front.getNext()==null)
		return true;
		return false;
	}
	void printQueue(){
		Node temp=front;
		
		while(temp!=null){
			if(temp.getNext()!=null)
			System.out.print("--> ("+temp.getData()+", "+temp.getNext().getData()+")");
			else
				System.out.println("--> ("+temp.getData()+", -1)");
			temp =temp.getNext();
			
		}
		System.out.println();
	}
	void printQueueFile(PrintWriter outfile){
			Node temp=front;
		while(temp!=null){
			if(temp.getNext()!=null)
			outfile.print("--> ("+temp.getData()+", "+temp.getNext().getData()+")");
			else
			outfile.print("--> ("+temp.getData()+", -1)");
			temp =temp.getNext();
			
		}
		outfile.println();
		//outfile.close();
	}
}
