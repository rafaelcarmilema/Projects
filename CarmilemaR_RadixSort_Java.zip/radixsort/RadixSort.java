package radixsort;
import java.io.PrintWriter;
public class RadixSort {

		int currentTable;
		int previousTable;
		String args[];
		int TotalDigit=0;
		int currentDigit=0; // so it will start from the end 
		int index;
		HashTable hashTable[]=new HashTable[2];
		
		RadixSort(String argu[]){
				hashTable[0]= new HashTable ();
				hashTable[1]= new HashTable ();
				args=argu;
				currentTable=0;
				TotalDigit=0;
		}
	int calcTotalDigit(int max) {
	    int digits = 0;
	    while (max > 0) {
	        max = max/10;
	        digits++;
	    }
	    return digits;
	}	
	int getIndex(String d){ //hash function		
			int digit;
	    String num = d;
	    int number;
	    number = Integer.parseInt(num); 
	    int mod = 10;
	    int div;	
	    for(int i = currentDigit; i > 0 ; i--){
	        mod *= 10;
	    }
	    div = mod/10;
	    digit = (number%mod)/div;	
	    return digit;
	}
	void add(String d){ //gets the right index and sets in the appropiate index in HashTable
		int index=getIndex(d);
		
		hashTable[currentTable].hashTable[index].addTail(d);
	}
	void sort(LinkedListStack stack,PrintWriter outfile){
		outfile.println("ORIGINAL");
		int largest=0;
		int currentQueue;
		String data="";
		int x;
		while(!stack.isEmpty()){ // pop everything from the stack until empty
			data=stack.pop();
			x= Integer.parseInt(data);
			
			int index=getIndex(data);
			hashTable[currentTable].hashTable[index].addTail(data);    // add into my current hashtable
			if(largest<x){			
				largest=x; 
			}
		}
		TotalDigit=calcTotalDigit(largest);
		System.out.println("Original "+currentTable);
		//outfile<<"Original:"<<endl;
		hashTable[currentTable].printTable();
		//outfile<<endl;
		
		hashTable[currentTable].printTableFile(outfile);///////
		//outfile<<endl;
		System.out.println();
	   
	    currentDigit++;
	    currentTable = 1;
	    previousTable = 0;
	    currentQueue = 0;
	    
		hashTable[currentTable].printTable();
	while(currentDigit < TotalDigit) {
		System.out.println();
		//hashTable[currentTable] =  new HashTable ();
		//outfile<<endl;
		//outfile<<"UNSORTED TABLE, CURRENT DIGIT "<<currentDigit<<endl;
		System.out.println("UNSORTED TABLE, CURRENT DIGIT "+currentDigit);
		outfile.println("UNSORTED TABLE, CURRENT DIGIT "+currentDigit);
		hashTable[previousTable].printTableFile(outfile);
		hashTable[previousTable].printTable();
		System.out.println();
		while (currentQueue < hashTable[previousTable].size) {
            while (!hashTable[previousTable].hashTable[currentQueue].isEmpty()) {
               String d = hashTable[previousTable].hashTable[currentQueue].deleteHead();
                int index = getIndex(d);
                
                hashTable[currentTable].hashTable[index].addTail(d);
				//cout<<"index "<<index<<" data "<<d<<endl;
            }
          
            //hashTable[currentTable]->printTable();
            currentQueue++;
        }
	  int temp = currentTable;
        currentTable = previousTable;
        previousTable = temp;
        currentQueue = 0;
        currentDigit++;
    }
	System.out.println("SORTED TABLE, CURRENT DIGIT "+currentDigit);
    hashTable[previousTable].printTable();
	outfile.println();
	outfile.println("SORTED TABLE, CURRENT DIGIT "+currentDigit);
    hashTable[previousTable].printTableFile(outfile);
	}
	public void printFile(PrintWriter outfile){
		outfile.println("test");
		
	}
}
