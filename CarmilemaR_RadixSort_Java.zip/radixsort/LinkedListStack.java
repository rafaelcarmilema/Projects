package radixsort;

import java.io.PrintWriter;

public class LinkedListStack {
	    public PrintWriter outfile;
		private Node Top;
		int count;
		String args[];
		//char** argv;
		
		public LinkedListStack(String argu[]){
			Top =null;
			count=0;
			args=argu;
		}	
		public void push(String d){	
			Node newTop;
			if(isEmpty()){
				newTop= new Node(d,null);
			//	newTop->data =d;
			//	newTop->next=NULL;
				Top= newTop;
				count++;
				
			}
			else{
				newTop= new Node(d,Top);
				//newTop->data=d;
				//newTop->next=Top;
				Top= newTop;
				count++;
			}
			//cout<<"inserted "<<d <<" # "<<count<<endl;
		}
		public String pop(){
			if(isEmpty()){
				System.out.println("The Stack is empty");
				return null;
			}
			else{
			
			Node temp=Top;
			String d=temp.getData();
			Top=Top.getNext();
			count--;
			return d;
			}
		}
		public Boolean isEmpty(){
			if(Top==null){
			return true;
			}
			return false;
			
		}
		void printStack(){
			int flag=0;
			System.out.println("STACK:");
			System.out.println("TOP");
			
			for(Node p=Top; p!=null;p=p.getNext()){
				//cout<<p->data<<" "<<flag<<endl;
			if(flag<10){
				if(p.getNext()!=null)
				System.out.print("--> ("+p.getData()+", "+p.getNext().getData()+")");
				else
					System.out.println("--> ("+p.getData()+", -1)");
				flag++;
				}
			else break;	
			}
			System.out.println();
		}
		void printTableFile(PrintWriter outfile){
			
	            int flag=0;	           
	            outfile.println("STACK");
	            outfile.print("TOP");
	        	for(Node p=Top; p!=null;p=p.getNext()){
	    		if(flag<10){
	    			if(p.getNext()!=null)
	    			outfile.print("--> ("+p.getData()+", "+p.getNext().getData()+")");
	    			else{
	    			outfile.println("--> ("+p.getData()+", -1)");
	    		}
	    		 flag++;
	    			}
	    		else{
	    			outfile.println();
	    		 break;	
	    			}
	    		  }

	    		//outfile.close();
	        
		
		}	
}	
