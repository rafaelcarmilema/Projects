package radixsort;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		LinkedListStack stack = new LinkedListStack(args);
		if ( args.length < 2 ){
			System.err.println("Invalid number of arguments.");
			System.exit(1);
			}
		    else {
	        File file = new File(args[0]);
	        String x="";
	        try {
	        	PrintWriter outfile = new PrintWriter(args[1]);
	            Scanner infile = new Scanner(file);
	            while (infile.hasNext()) {
	                x=infile.next();
	                stack.push(x);
	              // stack.printStack();
	                stack.printTableFile(outfile);
	            }
	            infile.close();
	            
	            RadixSort l1= new RadixSort(args);
	            l1.sort(stack,outfile);
	            outfile.flush();
	            outfile.close();
	        } 
	        catch (FileNotFoundException e) {
	            System.out.println("File not found.");
	        }
	        

	}
	
	
		
		
  }
}
