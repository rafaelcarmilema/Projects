package radixsort;

import java.io.PrintWriter;

public class HashTable {

		int size=10;
		LinkedListQueue []hashTable;

			HashTable(){
			  	hashTable= new LinkedListQueue [size];
			  	for(int i=0;i<size;i++){
			  		hashTable[i] = new LinkedListQueue();
			  	}
			
		}
		void printTable(){
			for(int i=0;i<size;i++){
				System.out.println("INDEX["+i+ "]");
				hashTable[i].printQueue();
				//cout<<i;
			}
		}
		void printTableFile(PrintWriter outfile){
			for(int i=0;i<size;i++){
				outfile.print("INDEX["+i+ "]");
				hashTable[i].printQueueFile(outfile);
				
			}
		
		
		}	
	
}
