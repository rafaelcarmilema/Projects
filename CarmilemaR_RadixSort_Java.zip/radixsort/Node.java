package radixsort;

public class Node{
	private Node next;	
    private String data;  

	//constructor
	
	public Node(String d){
		data=d;
		//next=null;
	}
	public Node(String d, Node n){
		data=d;
		next=n;
	}
	public String getData(){return data;}
	public Node getNext(){return next;}
	public void setNext(Node n){next =n;}
	
	
};