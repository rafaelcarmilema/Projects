#include <iostream>
#include<fstream>
#include <string> 
using namespace std;
class Node{
	private:
	Node* next;	
    string data;  
	public:  
	//constructor
	
	Node(string d){
		data=d;
		next=NULL;
	}
	Node(string d, Node* n){
		data=d;
		next=n;
	}
	~Node(){
	
		delete(next);
	}
	
	friend class LinkedListStack;
	friend class LinkedListQueue;
	friend class HashTable;
	
};
class LinkedListQueue{
	private:
		Node* front;
		Node* rear;
	public:
		int count=0;
	LinkedListQueue(){
		front = new Node ("-9999",NULL);
		rear = front;
		
	}	

	void addTail(string data){
	    rear->next = new Node(data,NULL);
		rear=rear->next;
	}
	
	string deleteHead(){
		Node* temp=front->next;
		if(isEmpty()){
			cout<<"The Queue is Empty"<<endl;
			return 0;
		}
	
		else{
			
			front->next=front->next->next;			
			string d=temp->data;
		//	cout<<d;
		//delete(temp);
			return d;
		}
	
	}
	bool isEmpty(){
		if(front->next==NULL)
		return true;
		return false;
	}
	void printQueue(){
		Node* temp=front;
		
		while(temp!=NULL){
			if(temp->next!=NULL)
			cout<<"--> ("<<temp->data<<", "<<temp->next->data<<")";
			else
			cout<<"--> ("<<temp->data<<", -1)";
			temp =temp->next;
			
		}
		cout<<endl;
	}
	void printQueueFile(char* argv[]){
			Node* temp=front;
		ofstream outfile;
		outfile.open(argv[2],ios:: out| ios::app );
		
		while(temp!=NULL){
			if(temp->next!=NULL)
			outfile<<"--> ("<<temp->data<<", "<<temp->next->data<<")";
			else
			outfile<<"--> ("<<temp->data<<", -1)";
			temp =temp->next;
			
		}
		outfile<<endl;
		//outfile.close();
	}

};
class LinkedListStack{
	private:
	Node* Top;
	int count;
	char** argv;
	public:
	LinkedListStack(char* args[]){
		Top =NULL;
		count=0;
		argv=args;
	}	
	void push(string d){	
		Node* newTop;
		if(isEmpty()){
			newTop= new Node(d,NULL);
		//	newTop->data =d;
		//	newTop->next=NULL;
			Top= newTop;
			count++;
			
		}
		else{
			newTop= new Node(d,Top);
			//newTop->data=d;
			//newTop->next=Top;
			Top= newTop;
			count++;
		}
		//cout<<"inserted "<<d <<" # "<<count<<endl;
	}
	string pop(){
		if(isEmpty()){
			cout<<"The Stack is empty"<<endl;
			exit(0);
		}
		else{
		
		Node* temp=Top;
		string d=temp->data;
		Top=Top->next;
		count--;
		free(temp);
		return d;
		}
	}
	bool isEmpty(){
		if(Top==NULL){
		return true;
		}
		return false;
		
	}
	void printStack(){
		int flag=0;
		cout<<"STACK:"<<endl;
		cout<<"TOP";
		
		for(Node* p=Top; p!=NULL;p=p->next){
			//cout<<p->data<<" "<<flag<<endl;
		if(flag<10){
			
			if(p->next!=NULL)
			cout<<"--> ("<<p->data<<", "<<p->next->data<<")";
			else
			cout<<"--> ("<<p->data<<", -1)";
			flag++;
			}
		else break;	
		}
		cout<<endl;
	}
	
	void printFile(){
	 	ofstream outfile;
		outfile.open(argv[2],ios:: out| ios::app );
		int flag=0;
		outfile<<"STACK:"<<endl;
		outfile<<"TOP";
		for(Node* p=Top; p!=NULL;p=p->next){
			//cout<<p->data<<" "<<flag<<endl;
		if(flag<10){
			if(p->next!=NULL)
			outfile<<"--> ("<<p->data<<", "<<p->next->data<<")";
			else{
			
			outfile<<"--> ("<<p->data<<", -1)";
			outfile<<endl;
		}
		 flag++;
			}
		else{
		
		outfile<<endl;
		 break;	
		
		}
		}
		 outfile<<endl;
		 outfile.close();	 
	}

	int getsize(){
		return count;
	}
};
class HashTable{
	public:
	int size=10;
	LinkedListQueue *hashTable;

		HashTable(){
		  	hashTable= new LinkedListQueue [size];	
		
	}
/*	void add(string d, int index){
		hashTable[index].addTail(d);
		
	}
*/
	int getIndex(string d){
		int index;
		char c=d[d.size()-1];
		index=c-'0';
		return index;
		
	}
	void printTable(){
		for(int i=0;i<size;i++){
			cout<<"INDEX["<<i<< "]";
			hashTable[i].printQueue();
			//cout<<i;
		}
	}
	void printTableFile(char* argv[]){
		ofstream outfile;
	    	outfile.open(argv[2],ios:: out| ios::app );
		for(int i=0;i<size;i++){
			ofstream outfile;
	    	outfile.open(argv[2],ios:: out| ios::app );
			outfile<<"INDEX["<<i<< "]";
			outfile.close();
			hashTable[i].printQueueFile(argv);
			
		}
	
	}	
};
class RadixSort{
	public:
		int currentTable;
		int previousTable;
		char** argv;
		int TotalDigit=0;
		int currentDigit=0; // so it will start from the end 
		int index;
		int test;
		HashTable* hashTable[2];
		
		RadixSort(char* arguments[]){
				hashTable[0]= new HashTable ();
				hashTable[1]= new HashTable ();
				argv=arguments;
				currentTable=0;
				TotalDigit=0;
		}
	int calcTotalDigit(int max) {
	    int digits = 0;
	    while (max > 0) {
	        max = max/10;
	        digits++;
	    }
	    return digits;
	}	
	int getIndex(string d){ //hash function		
			int digit;
	    string num = d;
	    int number;
	    number = atoi(num.c_str()); 
	    int mod = 10;
	    int div;	
	    for(int i = currentDigit; i > 0 ; i--){
	        mod *= 10;
	    }
	    div = mod/10;
	    digit = (number%mod)/div;	
	    return digit;
	}
	void add(string d){ //gets the right index and sets in the appropiate index in HashTable
		int index=getIndex(d);
		
		hashTable[currentTable]->hashTable[index].addTail(d);
	}
	void sort(LinkedListStack stack){
		ofstream outfile;
		outfile.open(argv[2],ios:: out| ios::app );
		//outfile<<"Original:"<<endl;
		int largest=0;
		int currentQueue;
		int hashTableT=2;
		string data="";
		int x;
		while(!stack.isEmpty()){ // pop everything from the stack until empty
			data=stack.pop();
			x= atoi(data.c_str());
			
			int index=getIndex(data);
			hashTable[currentTable]->hashTable[index].addTail(data);    // add into my current hashtable
			if(largest<x){			
				largest=x; 
			}
		}
		TotalDigit=calcTotalDigit(largest);
		cout<<"Original "<<currentTable<<endl;
		outfile<<"Original:"<<endl;
		hashTable[currentTable]->printTable();
		outfile<<endl;
		hashTable[currentTable]->printTableFile(argv);
		outfile<<endl;
		cout << endl;
	   
	    currentDigit++;
	    currentTable = 1;
	    previousTable = 0;
	    currentQueue = 0;
	    
		hashTable[currentTable]->printTable();
	while(currentDigit < TotalDigit) {
		cout<<endl;	
		hashTable[currentTable] =  new HashTable ();
		outfile<<endl;
		outfile<<"UNSORTED TABLE, CURRENT DIGIT "<<currentDigit<<endl;
		hashTable[previousTable]->printTableFile(argv);
		hashTable[previousTable]->printTable();
		cout<<endl;	
		while (currentQueue < hashTable[previousTable]->size) {
            while (!hashTable[previousTable]->hashTable[currentQueue].isEmpty()) {
               string d = hashTable[previousTable]->hashTable[currentQueue].deleteHead();
                int index = getIndex(d);
                
                hashTable[currentTable]->hashTable[index].addTail(d);
				//cout<<"index "<<index<<" data "<<d<<endl;
            }
          
            //hashTable[currentTable]->printTable();
            currentQueue++;
        }
	  int temp = currentTable;
        currentTable = previousTable;
        previousTable = temp;
        currentQueue = 0;
        currentDigit++;
    }
    hashTable[previousTable]->printTable();
	outfile<<endl;
	outfile<<"SORTED TABLE, CURRENT DIGIT "<<currentDigit<<endl;
   hashTable[previousTable]->printTableFile(argv);
	}
	
};
int main(int argc, char** argv) {
	 
	HashTable h;
	 if ( argc < 2 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {
		  string r="";
	      int x;
	      int largest=0;
	      
	     LinkedListStack test=(argv);
	      ofstream outfile;
			outfile.open(argv[2]);
	      while ( the_file>>r){	      	
	    	      test.push(r);
	    	      //test.printStack();    	      
	    	      test.printFile();   	      
	    	      cout<<endl;			  
	     	      }	     	      	     	    
	     	       the_file.close();
	     	       ifstream the_file ( argv[1] );
	      while ( the_file>>x){
			   if(largest<x) 
			   largest=x;   
			   }
		RadixSort l1(argv); 
		l1.sort(test); 
		
			//*ra = new LinkedListQueue();
			
			
	      the_file.close();
		

		 outfile.close();			
    return 0;
	
	
		
		}
	
	}
	

}
