#include<iostream>
#include<fstream>
#include<string>

using namespace std;


void insertOneDataItem(int a[],int x,int size);
void print(int a[],int x,std::ofstream &outputFile);
void bubbleUp(int a[]);
void bubbleDown(int a[]);
void buildHeap(std::ifstream &InputFile,std::ofstream &outputFile,int *&a,int size);
void deleteRoot(std::ofstream &outputFile,int *&a,int size);
void printDelete(int a[],int x,std::ofstream &outputFile);
bool isEmpty();
bool isFull(int a[],int size);
int count=0;
int i=1;
bool isEmpty(){
	if(count==0)
	return true;
	return false;
}
bool isFull(int a[],int size){
	if(a[0]==size-1)
	return true;
	return false;
}
void deleteRoot(std::ofstream &outputFile,int *&a,int size){
	int temp;
	for(int i=1;i<=count;i++)
	cout<<" "<<a[i]<<" ";
	if(a[0]==0){
			cout<<"heap is empty"<<endl;
			return;
		}
		outputFile<<endl;
		while(a[0]!=0){
	//cout<<"delete "<<a[1]<<endl;
		
			printDelete(a,a[1],outputFile);
			temp=a[1];
			a[1]=a[a[0]];
			a[a[0]]=temp;		
			a[0]--;
			bubbleDown(a);
		
	}
	cout<<endl;
	for(int i=count;i>=1;i--)
	cout<<" "<<a[i]<<" ";
	 outputFile<<"Final Heap"<<endl;
		 for(int i=count;i>=1;i--)
		 outputFile<<" "<<a[i]<<" ";
		
		outputFile.close();
	//for(int i=1;i<=count;i++)
//	cout<<" "<<a[i]<<" ";
	
}


void buildHeap(std::ifstream &InputFile,std::ofstream &outputFile,int *&a,int size)
{
	//ifstream the_file ( InputFile );
		int x;
		//int count=0;
		outputFile<<"size "<<size<<endl;
		outputFile<<"count "<<count<<endl;
		 while ( InputFile>>x){
			 ++count;
			 
			 
			 insertOneDataItem(a,x,size);
			 print(a,x,outputFile);	
		     
		 }
		 
		 
		 outputFile<<"Final Heap"<<endl;
		 for(int i=1;i<=count;i++)
		 outputFile<<" "<<a[i]<<" ";
		
		InputFile.close();
}
void insertOneDataItem(int a[],int x,int size){
	if(isFull(a,size)){
		cout<<"heap is full"<<endl;
		return;
	}
		 a[0]=count;
	     a[i]=x;
	     i++;
	 bubbleUp(a);


}
void bubbleUp(int a[]){
	
	
	int child;
	child=count;
	int parent;
	parent=child/2;
	//left=parent*2;
	//right=parent*2+1;
	
	while(parent>=1&&a[parent]>=a[child]){
		if(a[parent]>a[child]){
			int temp;
			temp=a[child];
			a[child]=a[parent];
			a[parent]=temp;
			child=parent;
			parent=parent/2;
			
		}
		
	
	
}
	
	
}
void bubbleDown(int a[]){
	cout<<endl;
	
	//for(int i=1;i<=count;i++)
	//cout<<" "<<a[i]<<" ";
	int left;
	int right;
	int temp;
	int min;
	int root=1;
	left=root*2;
	right=root*2+1;
	
			while(right<a[0]&&left<a[0]){
			
				if(a[left]<a[right]&&right<a[0]){
					 min=left;
					}
				else if(a[left]>a[right]&&right<a[0] ){
					min=right;
					}
				
					
				if(a[min]>a[root]){
				 return;
				  
				}
				else{
				
					temp=a[min];
					a[min]=a[root];
					a[root]=temp;
					root=min;
					left=root*2;
					right=root*2+1;
				}						
		}
			//for(int i=1;i<=count;i++)
//	cout<<" "<<a[i]<<" ";	
}

void printDelete(int a[],int x,std::ofstream &outputFile){
	int num=0;

	outputFile<<"count "<<a[0]<<" delete "<<x<<"   ";
	for(int i=1;i<=a[0];i++){
	    if(num<10){
		
		outputFile<<" "<<a[i]<<" ";
		num++;
		}
	}
	    outputFile<<endl;
	   
	

}
void print(int a[],int x,std::ofstream &outputFile){
	int num=0;
	
	
	outputFile<<"count "<<count<<" insert "<<x<<"   ";
	for(int i=1;i<=count;i++){
	    if(num<10){
		
		outputFile<<" "<<a[i]<<" ";
		num++;
		}
	}
	    outputFile<<endl;
	   
	

}

int main ( int argc, char *argv[] )
{


	 if ( argc < 2 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else {

	      int x;
	      int count=0;
	      int* heap;
	      // the_file.get ( x ) returns false if the end of the file
	      //  is reached or an error occurs
	      while ( the_file>>x){
	    	      count++;
	    	  	  //cout<<x<<endl;

	     	      }
	      the_file.close();

	      heap= new int[count+1];
	      ifstream the_file ( argv[1] );
	      ofstream output(argv[2]);
	      buildHeap(the_file,output,heap,count+1);
	      deleteRoot(output,heap,count+1);


    return 0;
	    }
	  }
}
