#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
using namespace std;
class Node{
	private:
	Node* next=NULL;	
    int xcoordinate;
	int ycoordinate;
	int clusterLabel;
	double distance;  
	public:  
	Node(int x,int y,int label,double d){
		xcoordinate=x;
		ycoordinate=y;
		clusterLabel=label;
		distance=d;
		next=NULL;
	}
	Node(int x,int y,int label,double d, Node* n){
		xcoordinate=x;
		ycoordinate=y;
		clusterLabel=label;
		distance=d;
		next=n;
	}
	~Node(){
		delete(next);
	}
	void Print(){
		cout<<"Info of the Node"<<endl;
		cout<<"x coordinate "<<xcoordinate<<endl;
		cout<<"y coordinate "<<ycoordinate<<endl;
		cout<<"cluster label "<<clusterLabel<<endl;
		cout<<"distance "<<distance<<endl;
	}
	friend class LinkedList;
	friend class Kmean;
};

class LinkedList{
	private:
		Node* head;
		Node*  dummy;
	public:
		LinkedList(){
			dummy = new Node(-9999,-9999,-9999,-9999);
			head=dummy;
		}
		~LinkedList(){
		/*	while (dummy != NULL)
       		 {
          Node* next = dummy->next;
          delete head;
          dummy = next;
        	}
			*/
		}
	void insertion(int x,int y,int label,double d){
		Node* temp = new Node(x,y,label,d);
		if(dummy->next==NULL){
			dummy->next=temp;
			head=dummy->next;
			}
		else{
			Node* curr=head;
			while(curr->next!=NULL){			
				curr=curr->next;
			}
			curr->next= temp;
		}		
	}	
	Node* deletion(){
		Node* curr =head;
		if(dummy->next==NULL){
			cout<<"list is empty"<<endl;
			return NULL;
		}
		else{
			while(curr!=NULL)
			curr= curr->next;
		}
		Node* temp=curr;
		delete(curr);
		return temp;
			
	}
	void printList(){
		Node* temp=head;
		while(temp!=NULL){
			temp->Print();
			temp=temp->next;
		}
	}
	void printListTextFile(int k,int r,int c, std::ofstream &output){
			Node* temp=head;
			output<<k<<endl;
			output<<r<<" "<<c<<" //"<<r<<" rows "<<c<<" columns"<<endl;
		while(temp!=NULL){
			output<<temp->xcoordinate<<" "<<temp->ycoordinate<<" //the pixel is in row "<<temp->xcoordinate<<" column "<<temp->ycoordinate<<" ID "<<temp->clusterLabel<<endl;
			temp=temp->next;
		}
		
	}
	friend class Kmean;
}; 
class Kmean{
		private:
		struct xycoord{
			int x;
			int y;
		};
		int K;
		xycoord* Kcentroids;
		//LinkedList* listHead;
		LinkedList listHead;
		int numRow;
		int numCol;
		bool flag=true;
		int** imageArray;
		
		public:	
		Kmean(int k,int r,int c,LinkedList points){
			K=k;
			numRow=r;
			numCol=c;
			Kcentroids = new xycoord[K+1];
			listHead = points;
			imageArray=new int*[numRow];
			for(int i = 0; i < numRow; ++i){
    		imageArray[i] = new int[numCol];
    		}
    		for(int r = 0; r < numRow; r++){
				    for(int c = 0; c < numCol; c++){
				    	imageArray[r][c]=0;
				    }
				}
		}// end of constructor

		void clustering(string image, string list){
			ofstream outfile2;	
			outfile2.open(image);
				outfile2<<"************************Original Image *******************"<<endl;
				//Node* temp=listHead.head;
				while(flag){	
				    Node* temp=listHead.head;	
					while(temp!=NULL){
						int x;
						int y;
						int l;
						 x = temp->xcoordinate;
				         y = temp->ycoordinate;
				         l = temp->clusterLabel;
				        imageArray[x][y]= l;
				        temp = temp->next;
					}
					displayImage();
					displayImageFile(outfile2);
					for(int i = 1; i <= K; i++){
				        int xTotal=0, yTotal=0, xCount=0, yCount=0;
				        Node* t = listHead.head;
					        while(t != NULL) {
					            if(t->clusterLabel == i){
					                int x = t->xcoordinate;
					                int y = t->ycoordinate;
					                xTotal += x;
					                yTotal += y;
					                xCount++;
					                yCount++;
					            }
					            t = t->next;
					        }
				        if(xCount != 0 && yCount != 0) {
				            Kcentroids[i].x = xTotal / xCount;
				            Kcentroids[i].y = yTotal / yCount;
				        	}
				        	
	   			 		}
						Node* current = listHead.head;
				    	flag = false;
					    while(current != NULL){
					        int currentLabel = current->clusterLabel;
					        int minimumK = current->clusterLabel;
					        double minDistance;
					        if(current->distance<0) {
					            minDistance = dFormula(current, Kcentroids[1]);
					        }
					        else{
					            minDistance = current->distance;
					        }
					        for(int i = 1; i <= K; i++){
					            double dist = dFormula(current, Kcentroids[i]);
					            if(dist <= minDistance){
					                minimumK = i;
					                minDistance = dist;
					            }
					        }
					        if(minimumK!= currentLabel) {
					            current->clusterLabel = minimumK;
					            current->distance = minDistance;
					            flag = true;
					        }
					        current = current->next;
					    }
				
	
				}//end of while
							for(int i=1;i<=K;i++){
								if(i==1)
					            imageArray[Kcentroids[i].x][Kcentroids[i].y]=-1;
					            else if(i==2)
					            imageArray[Kcentroids[i].x][Kcentroids[i].y]=-2;
					            else if(i==3)
					            imageArray[Kcentroids[i].x][Kcentroids[i].y]=-3;
					            else if(i==4)
					            imageArray[Kcentroids[i].x][Kcentroids[i].y]=-4;
					        }//end of for
					displayImage();
					outfile2<<"************************Final Image *******************"<<endl;
					displayImageFile(outfile2);
					ofstream outfile1;	
					outfile1.open(list);
		     		listHead.printListTextFile(K,numRow,numCol,outfile1);
		}
		double dFormula(Node* p,xycoord centroid){
			int x;
			int y;
			int xCen;
			int yCen;
			int xDist;
			int yDist;
			int Distance;
			 x=p->xcoordinate;
		     y=p->ycoordinate;
		     xCen=centroid.x;
		     yCen=centroid.y;
		     xDist=abs(x-xCen);
		     yDist=abs(y-yCen);
			Distance=sqrt(pow(xDist, 2.0) + pow(yDist, 2.0));
			return Distance;		
		}
		void displayImage(){
			for(int r = 0; r < numRow; r++){
			    for(int c = 0; c < numCol; c++){
			        if(imageArray[r][c] == 0) {
			            cout << " ";
			            }
			        else {
			            cout << imageArray[r][c];
			            }
			        }
			        cout << endl;
			    }
		}
		displayImageFile(std::ofstream &output){
			for(int r = 0; r < numRow; r++){
			    for(int c = 0; c < numCol; c++){
			        if(imageArray[r][c] == 0) {
			            output << " ";
			            }
			        else {
			            output << imageArray[r][c];
			            }
			        }
			        
			        output << endl;
			    }
			output<<"**********************************"<<endl;
			}
	
	};


int main(int argc, char** argv) {
if ( argc < 3 ) // argc should be 2 for correct execution
	    // We print argv[0] assuming it is the program name
	    cout<<"usage: "<< argv[0] <<" <filename>\n";
	  else {
	    // We assume argv[1] is a filename to open
	    ifstream the_file ( argv[1] );
	    // Always check to see if file opening succeeded
	    if ( !the_file.is_open() )
	      cout<<"Could not open file\n";
	    else { 
			//Kmean test;
			//test.clustering(the_file);    
	    	int r;
	    	int c=0;
	    	int k;
	    	int count=0;

	    	int numRow; 
	    	int numCol;
	    	int y,x;
	      	ofstream outfile;
	      	ofstream outfile2;
			//outfile.open(argv[2]);
			outfile2.open(argv[3]);
			string output1=argv[3];
			string output2=argv[2];
			//cout<<ra<<endl;
	      while ( the_file>>r&&count<3){	
	      	count++;
		  	  	if(count==1){
		  	  			k=r;
		  	  			cout<<r<<endl;
					}
				else if(count==2){
						numRow=r;
						cout<<r<<endl;	
					}
				else{
						numCol=r;
						cout<<r<<endl;
						break;
					}	
				}		  	  
	    LinkedList points;
	    int counter=1;
	     while ( the_file>>r>>c){
	     	if(counter>4) counter=1;
	     	//cout<<r<<" "<<c<<" "<<counter<<endl;
	     	points.insertion(r,c,counter,-9999);
	     	counter++;
		}
		//points.printListTextFile(k,numRow,numCol,outfile); 
		//points.printList();
		Kmean test(k,numRow,numCol,points);
			test.clustering(output1,output2);
			//test.displayImageFile(outfile2);
			
			//test.displayImage();  
		//cout<<"K "<<k<<" row "<<numRow<<" Col "<<numCol<<endl; 	      	     	    
	    the_file.close();			
		outfile.close();
		outfile2.close();			
    return 0;	
		}
	}
}
